var childWindow;
var globalActivityRequest;

window.addEventListener('DOMContentLoaded', function() {

  'use strict';

  navigator.mozSetMessageHandler('activity', function(activityRequest) {
    //console.log(JSON.stringify(activityRequest.source.data));
    
    globalActivityRequest = activityRequest;

    var data = activityRequest.source.data;
    if (data.type == 'url'){
      console.info('share:' + data.url);
      
      setTimeout(detectWindowClosing, 250);

      childWindow = window.open('http://b.hatena.ne.jp/bookmarklet.touch?url=' + encodeURIComponent(data.url));
      childWindow.onclose = function(){
        // impossible
        this.opener.close();
      };
    }
  });
});

function detectWindowClosing()
{
  if (childWindow.location){
    setTimeout(detectWindowClosing, 250);
  }
  else {
    globalActivityRequest.postResult(undefined);
//     window.close(); // close top frame
  }
}
