var globalChildWindow;
var globalActivityRequest;

navigator.mozSetMessageHandler('activity', function(activityRequest) {
  globalActivityRequest = activityRequest;

  var data = activityRequest.source.data;
  if (data.type == 'url'){
    globalChildWindow = window.open('https://b.hatena.ne.jp/bookmarklet.touch?url=' + encodeURIComponent(data.url));
    detectWindowClosing();
  }
});

function detectWindowClosing()
{
  if (globalChildWindow && globalChildWindow.location)
    setTimeout(detectWindowClosing, 500);
  else
    globalActivityRequest.postResult(undefined);
}
